import glob
from PIL import Image

def create_gif(image_paths, output_path, duration=1500):
    images = []
    for path in image_paths:
        try:
            img = Image.open(path)
            images.append(img)
        except Exception as e:
            print(f"Error loading image {path}: {e}")
            
    if not images:
        print("No images loaded.")
        return
        
    print(f"Generating GIF from {len(images)} images...")
    images[0].save(
        output_path,
        save_all=True,
        append_images=images[1:],
        duration=duration,
        loop=0
    )
    print(f"GIF saved successfully to {output_path}")

if __name__ == "__main__":
    # The 4 panel images we generated
    image_paths = [
        "/home/sam/.gemini/antigravity/brain/779918d7-24eb-49db-9148-13ad10be5273/laroe_webtoon_cut1_problem_v2_1772340341407.png",
        "/home/sam/.gemini/antigravity/brain/779918d7-24eb-49db-9148-13ad10be5273/laroe_webtoon_cut2_solution_1772340065208.png",
        "/home/sam/.gemini/antigravity/brain/779918d7-24eb-49db-9148-13ad10be5273/laroe_webtoon_cut3_action_1772340145522.png",
        "/home/sam/.gemini/antigravity/brain/779918d7-24eb-49db-9148-13ad10be5273/laroe_webtoon_cut4_result_1772340161475.png"
    ]
    output_path = "/home/sam/gitsam/llm-jamstack-test/laroe_webtoon_ad.gif"
    
    # 1500ms (1.5 seconds) per frame
    create_gif(image_paths, output_path, duration=2000)
